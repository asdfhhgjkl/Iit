class StorageFolderNames {
  static const String profilePics = 'profile_pics';
  static const String photos = 'image';
  static const String videos = 'video';
  static const String stories = 'stories';

  StorageFolderNames._();
}
