// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
apiKey: "AIzaSyCS8rW4tCCPNQ_dFJe3Gy5ktsWwEn9wbx0",
authDomain: "kbook-217fb.firebaseapp.com",
projectId: "kbook-217fb",
storageBucket: "kbook-217fb.firebasestorage.app",
messagingSenderId: "559372724520",
appId: "1:559372724520:web:a817df6095ee20ca59881d",
measurementId: "G-5GY2QD58S7"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);